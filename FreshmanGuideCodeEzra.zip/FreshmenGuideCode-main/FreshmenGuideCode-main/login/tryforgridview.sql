USE [FunUniversity]
GO

INSERT INTO [dbo].[StudentFeedback]
           ([StudentNumber]
           ,[Name]
           ,[Email])
     VALUES( 'c8494734', 'John', 'John@gmail.com');

		   INSERT INTO [dbo].[StudentFeedback]
           ([StudentNumber]
           ,[Name]
           ,[Email])
     VALUES
           ('c8494735'
           ,'Jess',
           'Jess@gmail.com')
GO


