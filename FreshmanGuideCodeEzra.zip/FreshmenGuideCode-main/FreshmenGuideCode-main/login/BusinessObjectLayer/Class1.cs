﻿using System;

namespace BusinessObjectLayer
{
    public class Class1
    {
    }
}
